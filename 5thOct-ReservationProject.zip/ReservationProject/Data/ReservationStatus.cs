﻿namespace ReservationProject.Data
{
    public class ReservationStatus
    {
        public int Id { get; set; }
        public string Name { get; set; }

    }
}